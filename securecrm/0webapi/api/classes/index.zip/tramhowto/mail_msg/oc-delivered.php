<?php
$sql = 'SELECT * FROM `trhwp_wc_order_stats` WHERE order_id="'.$id.'"';
$result = $dbtrht->query($sql);
$row = $result->fetch_assoc();
$oid = $row['order_id'];
$timestamp = $row['date_created'];
$rowss['status'] = $row['status']=='wc-processing'?'Pending':$row['status'];

$sql1 = 'select * from trhwp_postmeta where post_id="'.$row['order_id'].'" AND meta_key="_billing_email"';	
$result1 = $dbtrht->query($sql1);
$rows = $result1->fetch_assoc();
$toemail = mb_convert_encoding($rows['meta_value'], "UTF-8", "UTF-8");
$invid = "#".$row['order_id'];

$tids = array();
$tsql = "SELECT * FROM `tbl_traking_ids` WHERE order_id='".$id."'";
$tresult = $dbtrht->query($tsql);
while($rows1 = $tresult->fetch_assoc()) {
	array_push($tids, $rows1['tracking_id']);
}

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_city"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$ccity = mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");
		
		
$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_address_index"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$caddress = mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_first_name" ';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();

$sql2 = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_last_name" ';	
$result12 = $dbtrht->query($sql2);
$row2 = $result12->fetch_assoc();
$name = mb_convert_encoding($row['meta_value']." ".$row2['meta_value'], "UTF-8", "UTF-8");

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_postcode"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$czip = mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_shipping_country"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$ccountry = mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_billing_phone"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$cbillingphone = mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");

$sql = 'select * from trhwp_postmeta where post_id="'.$oid.'" AND meta_key="_billing_email"';	
$result1 = $dbtrht->query($sql);
$row = $result1->fetch_assoc();
$cemail =  mb_convert_encoding($row['meta_value'], "UTF-8", "UTF-8");
		
$total = 0;
$str = '';
$array = array();
$result = $dbtrht->query("select * from trhwp_woocommerce_order_items Where order_id='".$oid."' AND order_item_type='line_item'");
while($rows = $result->fetch_assoc()) {	
	$arr['pname'] = $rows['order_item_name']."/".$this->get_product_mgin($rows['order_item_id']);
	$arr['qty'] = $this->get_product_qtyin($rows['order_item_id']);
	$arr['price'] = $this->get_product_totin($rows['order_item_id'])/$arr['qty'];
	
	$str .='<tr>
			<td>'.$arr['pname'].'</td>
			<td>'.$arr['qty'].'</td>
			<td>$'.$arr['price'].'</td>
			<td>$'.($arr['qty']*$arr['price']).'</td>
		  </tr>';
		  $total = $total + ($arr['qty']*$arr['price']);
		  
	array_push($array, $arr);
}

$str .= '<tr>
			<td></td>
			<th colspan="2" align="right" style="border-top:2px solid gray;"><b>Sub Total: </b></th>
			<td style="border-top:2px solid gray;">$'.$total.'</td>
		</tr>';
		
		
	if($total>350) {
		$str .= '<tr>
					<th colspan="3" align="right"><b>Shipping Free: </b></th>
					<td>$00.00</td>
				</tr>';
	} else {
		$str .= '<tr>
					<th colspan="3" align="right"><b>Shipping: </b></th>
					<td>$20.00</td>
				</tr>';
	}
	$dis = 00;
	if($total>350) {
		$str .='<tr>
				<td></td>
				<th colspan="2" align="right"><b>Total: </b></th>
				<td>$'.($total-$dis).'</td>
			</tr>';
			$total = $total-$dis;
	} else {
		$str .='<tr>
				<td></td>
				<th colspan="2" align="right"><b>Total: </b></th>
				<td>$'.($total+20).'</td>
			</tr>';
			$total = $total+20;
	}
		
				
				
				
$msg ='';

$msg .='<table class="es-content esd-header-popover" cellspacing="0" cellpadding="0" align="center" width="600">
	<tbody>
		
		<tr>
			<td colspan="2" align="center">
				<br>
				<span><img src="https://oneglobalpharma.com/greentik.png" style="width:32px;"></span>
				<br>
				 <h3 style="color: #009b00;">Your Order Delivered Successfully.</h3>
				 <p>What\'s next? Please confirm that you received your items by clicking below option</p>
				 <h4 style="background-color: #e5e5e5;padding: 5px; width: fit-content;border-radius: 25px;border: 2px solid #bcbcbc;color:#808080;">ORDER ID: '.$invid.'</h4>
				 
				 
				 <a href="https://oneglobalpharma.com/intermediate/cust_del_complete.php?web=tramhto&id='.$id.'" style="background-color: #63ffdb;padding: 5px 10px;border: 2px solid #00e3d9;border-radius: 25px;font-weight:600;color:#000;text-decoration:none;">Yes, i received my order</a><br><br>
				 
				 <a href="https://oneglobalpharma.com/intermediate/cust_not_recv_order.php?web=tramhto&id='.$id.'" style="background-color: #63ffdb;padding: 5px 10px;border: 2px solid #00e3d9;border-radius: 25px;font-weight:600;color:#000;text-decoration:none;">I have not received my order yet</a><br><br>
				 
				 <a href="https://oneglobalpharma.com/intermediate/miss_medication_recv.php?web=tramhto&id='.$id.'" style="background-color: #63ffdb;padding: 5px 10px;border: 2px solid #00e3d9;border-radius: 25px;font-weight:600;color:#000;text-decoration:none;">Received incomplete/incorrect/duplicate or expired medication</a>
				 <br>
				 <br>
			</td>
		</tr>
		
		<tr>
		    <td colspan="2">
			<table align="center" width="100%;" cellpadding="0" cellspacing="0">
				<tr>
					<td style="background-color:#f4f4f4;padding:10px;">
						<h4 style="margin: 0px;">ORDER DETAILS</h4>
					</td>
					<td style="background-color:#f4f4f4;padding:10px;width: 235px;">
						<h4 style="margin: 0px;">SHIPPING ADDRESS</h4>
					</td>
				</tr>
				<tr>
					<td>
						<table align="center" width="100%;">
							<tr>
								
								<th style="text-align:left;height:50px;">Name</th>
								<th style="text-align:left;">Qty</th>
								<th style="text-align:left;">Price</th>
								<th style="text-align:left;">Total</th>
							</tr>
							'.$str.'
						</table>
					</td>
					<td style="padding-left: 12px;vertical-align: top;padding-top: 19px;border-left: 2px solid #d1d1d1;">
						<h4 style="margin:0px;">'.$name.'</h4>
						<p>'.$caddress.'<br>'.$ccity.'-'.$czip.',('.$ccountry.').<br>'.$cbillingphone.'<br>'.$cemail.'</p>
						<span style="font-weight:400;">(Shipping Time 15-21 Days)</span>
					</td>';
					
			
		$msg .='</tr>
				<tr>
					<td style="padding-top: 0px;" colspan="2">
						<hr style="border-top:3px solid #f8f8f8;">
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;" colspan="2">
						<p style="margin:0px;color:#001fcc;font-size:17px;"><b>Order Date:</b> '.date("d M, Y", strtotime($timestamp)).' (On this day you paid us)</p>
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;" colspan="2">
						<hr style="border-top:3px solid #f8f8f8;">
						<br>
						<br>
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;" colspan="2">
						<table cellspacing="0" border="0" cellpadding="0" width="550px" align="center" >
							<tr>
								<td></td>
								<td></td>';
								
								if($rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
									$msg .= '<td style="text-align: center;position: relative;right: -46px;color: #00a820;"></td>';
								} else {
									$msg .= '<td></td>';
								}
								$msg .='<td></td>
							</tr>
							
							<tr>';
								
								if($rowss['status']=="Processed" || $rowss['status']=="Shipped" || $rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
									$msg .= '<td>
												<span>
													<img src="https://oneglobalpharma.com/greentik.png" style="width:20px;padding-left: 5px;">
												</span>
											</td>';
								}
								
								
								if($rowss['status']=="Shipped" || $rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
									$msg .= '<td>
												<span>
													<img src="https://oneglobalpharma.com/greentik.png" style="width:20px;padding-left: 5px;">
												</span>
											</td>';
								}
								
								if($rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
									$msg .= '<td>
												<span>
													<img src="https://oneglobalpharma.com/greentik.png" style="width:20px;padding-left: 5px;">
													<span style="color:#00a820;">
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
													On the way ?</span>
												</span>
											</td>';
								}
									
								if($rowss['status']=="Delivered") {
									$msg .= '<td>
											<span>
													<img src="https://oneglobalpharma.com/greentik.png" style="width:20px;float:right;">
												</span>
											</td>';
								}
								
								$msg .= '</tr>
										<tr>';
								
							if($rowss['status']=="Processed" || $rowss['status']=="Shipped" || $rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
								$msg .= '<td style="vertical-align: top;color: #309a00;">
											<span style="padding: 3px 11px;
													 background-color: #309a00;
													 border-radius: 50%;">
													 </span>
													<div style="height: 4px;
																width: 118px;
																background-color: #309a00;
																display: inline-block;"></div>
													 <br> 
													<b>Processed</b><br>
													<span style="color:#9b9b9b;">Payment Received</span>
										</td>';
							} else {
								$msg .= '<td style="vertical-align: top;color: #adadad;">
											<span style="padding: 3px 11px;
													 background-color: #adadad;
													 border-radius: 50%;">
													 </span>
													 <div style="height: 4px;
																	width: 118px;
																	background-color: #adadad;
																	margin-top: -12px;
																	display: inline-block;"></div>
													 <br>
													<b>Processed</b><br>
										</td>';
							}
							
							
							if($rowss['status']=="Shipped" || $rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
								$msg .=	'<td>
											<span style="padding: 3px 11px;
													 background-color: #309a00;
													 border-radius: 50%;">
													 </span>
													 <div style="height: 4px;
																	width: 102px;
																	background-color: #309a00;
																	margin-top: -12px;
																	z-index:-1;
																	display: inline-block;"></div>
													 <br>
													<b style="color:#309a00;" >Shipped</b><br>
													<span style="color:#9b9b9b;">Item Shipped</span>			
										</td>';
							} else {
								$msg .=	'<td>
											<span style="padding: 3px 11px;
													 background-color: #adadad;
													 border-radius: 50%;">
													 </span>
													 <div style="height: 4px;
																	width: 102px;
																	background-color: #adadad;
																	margin-top: -12px;
																	display: inline-block;"></div>
													 <br>
													<b style="color:#adadad;" >Shipped</b><br>	
													<span style="color:#fff;">Item Shipped</span>	
										</td>';
							}
							
							if($rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
								$msg .= '<td>
											<span style="padding: 3px 11px;
													 background-color: #309a00;
													 border-radius: 50%;">
													 </span>
													 <div style="height: 4px;
																	width: 246px;
																	background-color: #309a00;
																	margin-top: -12px;
																	display: inline-block;"></div>
													 <br>
													  
													<b style="color:#309a00;" >Tracking</b><br>
													<span style="color:#9b9b9b;">Tracking send on email</span>
										</td>';
									
							} else {
								$msg .= '<td>
											<span style="padding: 3px 11px;
													 background-color: #adadad;
													 border-radius: 50%;">
													 </span>
													 <div style="height: 4px;
																	width: 246px;
																	background-color: #adadad;
																	margin-top: -12px;
																	display: inline-block;"></div>
													 <br>
													  
													<b style="color:#adadad;" >Tracking</b><br>
													<span style="color:#fff;">Tracking send on email</span>
										</td>';
							}
							
							if($rowss['status']=="Delivered") {
								$msg .=	'<td align="right" style="vertical-align: top;">
											<div style="height: 4px;
																	width: 100px;
																	background-color: #309a00;
																	margin-top: -12px;
																	display: inline-block;"></div>
											<span style="padding: 3px 11px;
													 background-color: #309a00;
													 border-radius: 50%;">
													 </span>
													 
													 <br>
													<b style="color:#309a00;" >Delivered</b><br>
													<span style="color:#9b9b9b;">Item Delivered</span>			
										</td>';
							} else {
								$msg .=	'<td align="right" style="vertical-align: top;">
										<div style="height: 4px;
															width: 100px;
															background-color: #adadad;
															margin-top: -12px;
															display: inline-block;"></div>
										<span style="padding: 3px 11px;
											 background-color: #adadad;
											 border-radius: 50%;">
											 </span>
											 <br>
											<b style="color:#adadad;" >Delivered</b><br>
											<span style="color:#fff;">Item Delivered</span>			
								</td>';
							}
				
				
						$msg .= '</tr>
							<tr>
							<td></td>
								<td colspan="2">';
								
								if($rowss['status']=="Tracking" || $rowss['status']=="Delivered") {
									
									foreach($tids as $key=> $value):
										$msg .= '<br>Package '.($key+1).'. <a href="https://t.17track.net/en#nums='.$value.'" style="margin-bottom: 10px;color: #fff;text-decoration: none;background-color: #8cb3ff;padding: 5px 21px;border-radius: 3px;display: inline-block;">Track Now</a>';
									endforeach;
								} 
								$msg .='</td>
								<td></td>
								
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;" colspan="2">
						<hr style="border-top:3px solid #f8f8f8;">
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;text-align:center;" colspan="2" >
					<br><br>
						<a href="https://oneglobalpharma.com/intermediate/oc_sts_report.php?web=tramhto&sts='.$rowss['status'].'&id='.$id.'" style="padding: 10px 20px;
										background-color: #4c89ff;
										color: #fff;
										text-decoration: none;
										font-size: 20px;
										border: 2px solid #0e60ff;
										border-radius: 25px;">Please click here and let us know that you got this email</a>
										<br>
					</td>
				</tr>
				<tr>
					<td style="padding-top: 0px;text-align:center;font-size:20px;" colspan="2" >
					<br>
					<p><b>Need help with your order (for issues or query).</b><br>
						Please choose your suitable way to contact us.
					</p>
					</td>
				</tr>
				<tr>
					<td colspan="2" >
					<br>
					<br>
						<table width="100%" style="text-align:center;">
							<tr>
								<td width="30%">
									<p>
									<a href="https://oneglobalpharma.com/intermediate/help_center.php" style="	border:2px solid #0085eb;
														padding: 22px;
														color: #0085eb;
														font-size: 17px;
														text-decoration: none;
														font-weight:700;
														border-radius: 7px;">Help center</a>
									</p>
								</td>
								<td width="40%">
									<span style="background-color: #0085eb;
												padding: 6px 17px;
												border-radius: 25px;
												color: #fff;
												font-size: 20px;    
												position: relative; top: 31px;">Support</span>
									<p style="	border:2px solid #0085eb;
														padding: 22px;
														color: #0085eb;
														font-size: 17px;
														text-decoration: none;
														border-radius: 7px;" >
										<b>Call Us: +1 315 515 4364</b><br>
										<span>OR</span><br>
										<span>Reply Back on same email</span>
									</p>
								</td>
								<td width="30%">
									<p>
									<a href="https://oneglobalpharma.com/intermediate/rep_an_issue.php?web=tramhto&id='.$id.'" style="	border:2px solid #0085eb;
														padding: 22px;
														color: #0085eb;
														font-size: 17px;
														text-decoration: none;
														font-weight:700;
														border-radius: 7px;">Report an issue</a>
									</p>
								</td>
							</tr>
						</table>
						<br>
					<br>
					</td>
				</tr>
				
				<tr>
					<td style="padding: 18px;background-color: #f0f5ff;" colspan="2" >
					<p><b>3 Things you have agreed on</b><br>
						<ol>
							<li>I will not mention anything about the purchase of medications (with Credit/debit Card Company or PayPal).</li>
							<hr>
							<li>Instead I will mention that i paid for Website Advertising Services as showed in my cart on checkout.</li>
							<hr>
							<li>In case of issues related to my order, I agree to contact your Customer Support instead of making chargeback or dispute with Credit/debit Card Company or PayPal.</li>
						</ol>
					</p>
					</td>
				</tr>
				
				
			</table>
			</td>
		</tr>
	</tbody>
</table>';

sendmail("admin@tramadol-howto.com", "Tramadol How-to", $toemail, "Your Order Delivered Successfully | tramadol-howto.com", $msg);

?>